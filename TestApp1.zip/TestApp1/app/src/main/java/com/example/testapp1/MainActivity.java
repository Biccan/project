package com.example.testapp1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.firestore.GeoPoint;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Currency;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements LocationListener {
    LocationManager locationManager;
    Geocoder geocoder;
    Location location;
    Double lat;
    Double lon;
    List<Address> countries;
    String countryCode;
    HashMap<String, Double> currencies = new HashMap<>();
    Set<Currency> allCurrencies = Currency.getAvailableCurrencies();
    Iterator iterator = allCurrencies.iterator();
    String startCurrency = "EUR";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
        }

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        if(lat == null  || lon == null)
        {
           location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
           if(location != null)
           {
               lat = location.getLatitude();
               lon = location.getLongitude();
           }

           else
           {
               location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
               if(location != null)
               {
                   lat = location.getLatitude();
                   lon = location.getLongitude();
               }
           }
        }

        geocoder = new Geocoder(this, Locale.getDefault());

            try {
                do {
                    countries = geocoder.getFromLocation(lat, lon, 1);
                } while (countries == null);
            } catch (IOException e) {
                e.printStackTrace();
            }


        ArrayList<String> currenciesNames = new ArrayList<>();

        if(countries!=null)
        {
            countryCode = countries.get(0).getCountryCode();
        }

        for(int i = 0; i<allCurrencies.size(); i++)
        {
            if(iterator.hasNext()) {
                Currency temp = (Currency) iterator.next();
                currenciesNames.add(temp.getCurrencyCode());
                if(temp.getCurrencyCode().startsWith(countryCode))
                    startCurrency = temp.getCurrencyCode();

            }
        }

        Collections.sort(currenciesNames);

        String request = null;
        for(int i = 0; i<currenciesNames.size(); i++)
        {
            if(request == null)
                request = currenciesNames.get(i);
            else
                request = request +","+ currenciesNames.get(i);
        }


        Button btn = findViewById(R.id.button);
        EditText input = findViewById(R.id.txtInput);
        TextView output = findViewById(R.id.txtResult);
        output.setText("0");


        Spinner spinnerfrom = (Spinner) findViewById(R.id.spinner2);
        Spinner spinnerto = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, currenciesNames);

        //serverRequest("http://data.fixer.io/api/latest?access_key=1a0270afc52e972dfd073d0ba5f340e3&symbols="+currenciesNames+"&format=1", currenciesNames, currencies);
        serverRequest("http://data.fixer.io/api/latest?access_key=fdd8b0c11b821583452e43fcd5a5fb69&symbols=" + currenciesNames + "&format=1", currenciesNames, currencies, new VolleyCallBack() {
            @Override
            public void onSuccess() {

                spinnerfrom.setAdapter(adapter);

                if(startCurrency != null)
                    spinnerfrom.setSelection(currenciesNames.indexOf(startCurrency));

                spinnerto.setAdapter(adapter);
                System.out.println("OnResponse4: " + currenciesNames.size());

            }
        });

        //Rates.updatedRates(ratesArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerfrom.setAdapter(adapter);

        if(startCurrency != null)
            spinnerfrom.setSelection(currenciesNames.indexOf(startCurrency));

        spinnerto.setAdapter(adapter);
        System.out.println("OnResponse3: " + currenciesNames.size());
        spinnerfrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (!(input.getText().toString().equals("")))
                    output.setText(Double.toString(convert(Double.parseDouble(input.getText().toString()), currencies)));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (!(input.getText().toString().equals("")))
                    output.setText(Double.toString(convert(Double.parseDouble(input.getText().toString()), currencies)));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ExampleActivity.class);
                intent.putExtra("currentCurrency", startCurrency);
                intent.putExtra("map", currencies);

                //serverRequest("http://data.fixer.io/api/latest?access_key=1a0270afc52e972dfd073d0ba5f340e3&symbols=EUR,GBP,KRW,CNY,SEK,USD,JPY&format=1");
                startActivity(intent);
            }
        });

        input.getText().clear();

        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!TextUtils.isEmpty(s.toString())) {
                    output.setText(Double.toString(convert(Double.parseDouble(s.toString()), currencies)));
                }
            }
        });
    }

    //skala här: exempelvis 1*getRates() för euro.
    double convert(double input, HashMap<String, Double> currencies) {
        double scale = -1;
        Spinner spinnerFrom = findViewById(R.id.spinner2);
        Spinner spinnerTo = findViewById(R.id.spinner3);
        String selectedFrom = spinnerFrom.getSelectedItem().toString();
        String selectedTo = spinnerTo.getSelectedItem().toString();


        double codeFrom = currencies.get(selectedFrom);
        double codeTo = currencies.get(selectedTo);

        double answer = input * (codeTo / codeFrom);
        DecimalFormat df = new DecimalFormat("0.00000");

        return Double.parseDouble(df.format(answer));
    }

    public void serverRequest(String url, List<String> currenciesNames, HashMap<String, Double> curr, final VolleyCallBack callBack) {
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.v("Response: ", response.toString());
                        try {

                            Log.v("Shit: ", response.getJSONObject("rates").toString());
                            System.out.println("OnResponse1: " + response.getJSONObject("rates").getDouble("GBP"));

                            for(int i = 0; i<currenciesNames.size(); i++)
                            {
                                    try{
                                        response.getJSONObject("rates").getDouble(currenciesNames.get(i));
                                    }
                                    catch (JSONException e)
                                    {
                                        currenciesNames.remove(i);
                                        i--;
                                        continue;
                                    }

                                curr.put(currenciesNames.get(i), response.getJSONObject("rates").getDouble(currenciesNames.get(i)));

                            }


                            currencies = curr;


                            System.out.println("OnResponse2: " + curr.get("EUR"));
                            callBack.onSuccess();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Response: ", error.toString());
            }
        }
        );

        queue.add(jsonObjectRequest);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        lat = location.getLatitude();
        lon = location.getLongitude();
    }

    public interface VolleyCallBack
    {
        void onSuccess();
    }

    /*public static void getAddressFromLocation(
            final Location location, final Context context, final Handler handler) {
        Thread thread = new Thread() {
            @Override public void run() {
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                String result = null;
                try {
                    List<Address> list = geocoder.getFromLocation(
                            location.getLatitude(), location.getLongitude(), 1);
                    if (list != null && list.size() > 0) {
                        Address address = list.get(0);
                        // sending back first address line and locality
                        result = address.getAddressLine(0) + ", " + address.getLocality();
                    }
                } catch (IOException e) {

                } finally {
                    Message msg = Message.obtain();
                    msg.setTarget(handler);
                    if (result != null) {
                        msg.what = 1;
                        Bundle bundle = new Bundle();
                        bundle.putString("address", result);
                        msg.setData(bundle);
                    } else
                        msg.what = 0;
                    msg.sendToTarget();
                }
            }
        };
        thread.start();
    }

    private class GeocoderHandler extends AsyncTask<URL, Integer, Long> {
        protected Long doInBackground(URL... urls) {
            int count = urls.length;
            long totalSize = 0;
            for (int i = 0; i < count; i++) {
                totalSize += Downloader.downloadFile(urls[i]);
                publishProgress((int) ((i / (float) count) * 100));
                // Escape early if cancel() is called
                if (isCancelled()) break;
            }
            return totalSize;
        }

        protected void onProgressUpdate(Integer... progress) {
            setProgressPercent(progress[0]);
        }

        protected void onPostExecute(Long result) {
            showDialog("Downloaded " + result + " bytes");
        }
    }*/

}


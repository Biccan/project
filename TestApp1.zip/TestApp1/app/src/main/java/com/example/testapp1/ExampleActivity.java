package com.example.testapp1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExampleActivity extends Activity {

    ArrayList<String> list = new ArrayList();
    ArrayList<String> currencyList;
    String startCurrency;
    HashMap<String, Double> currencies;

    ArrayAdapter<String> arrayAdapter;
    String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.examplelayout);

        Button btn = findViewById(R.id.button2);
        final ListView listView = (android.widget.ListView) findViewById(R.id.listV);

        startCurrency = getIntent().getExtras().getString("currentCurrency");
        currencies = (HashMap<String, Double>) getIntent().getSerializableExtra("map");

        for (Map.Entry<String, Double> entry : currencies.entrySet()) {
            list.add(entry.getKey());
        }

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, generateCurrencyRates(startCurrency));

        listView.setAdapter(arrayAdapter);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setSelection(list.indexOf(startCurrency));
        selected = startCurrency;


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                //serverRequest("http://data.fixer.io/api/latest?access_key=1a0270afc52e972dfd073d0ba5f340e3&symbols=EUR,GBP,KRW,CNY,SEK,USD,JPY&format=1");
                startActivity(intent);
            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(list.get(position) != null)
                    selected = list.get(position);
                currencyList = new ArrayList<>(generateCurrencyRates(selected));

                arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, currencyList);
                listView.setAdapter(arrayAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public ArrayList<String> generateCurrencyRates(String currency) {

        ArrayList<String> tempList = new ArrayList<>(list);

        for (int i = 0; i < currencies.size(); i++) {

            tempList.set(i, list.get(i)+ ": " + convert(currency, list.get(i), currencies));
        }

        return tempList;
    }

    double convert(String selected, String to, HashMap<String, Double> currencies) {
        double scale = -1;

        double answer = (currencies.get(to)  / currencies.get(selected));
        DecimalFormat df = new DecimalFormat("0.00000");

        return Double.parseDouble(df.format(answer));
    }
}

/*package com.example.testapp1;

import android.app.DownloadManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.net.URL;

public class functions {

    public JSONObject serverRequest(String str)
    {
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        String url = "http://data.fixer.io/api/latest?access_key=1a0270afc52e972dfd073d0ba5f340e3&symbols=EUR,GBP,KRW,CNY,SEK,USD,JPY&format=1";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Response: ", error.toString());
            }
        }
        );

        queue.add(stringRequest);
        return null;
    }

}*/

package com.example.testapp1;

public class Rates {

    /*static public void updatedRates(double[] rates){

        EUR = rates[0];
        GBP = rates[1];
        KRW = rates[2];
        CNY = rates[3];
        SEK = rates[4];
        USD = rates[5];
        JPY = rates[6];
}*/

    public static double EUR = 1.00;
    public static double GBP = 0.85;
    public static double KRW = 1350.60;
    public static double CNY = 7.3011;
    public static double SEK = 10.115;
    public static double USD = 1.1440;
    public static double JPY = 130.34;



}


